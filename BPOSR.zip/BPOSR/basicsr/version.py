# GENERATED VERSION FILE
# TIME: Mon Dec  9 22:43:20 2024
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
